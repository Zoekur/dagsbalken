package com.dagsbalken.app.ui.theme

// This file previously declared `val Typography` which duplicated `Typography.kt`.
// Kept placeholder to avoid accidental removal in VCS; actual typography is defined in Typography.kt.
