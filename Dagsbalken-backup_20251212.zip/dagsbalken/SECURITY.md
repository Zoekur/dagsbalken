# Security Policy

## Reporting a Vulnerability

We take the security of this project seriously. If you have discovered a security vulnerability, please do not disclose it publicly.

### How to Report

Please report vulnerability to the project maintainers directly. You can open an issue or contact the maintainer via email if available.

### Timelines

We will make our best effort to address the vulnerability as soon as possible.
